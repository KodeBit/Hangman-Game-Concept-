//
//  GameManager.swift
//  Hangman Game
//


import UIKit

protocol GameProtocol: AnyObject {
    func gameDataFetched(_ data: [String])
}

class GameDataManager {
    
    weak var delegate: GameProtocol?
    
    func fetchData() {
        var wordStrings = [String]()
        
        if let fileURL = Bundle.main.url(forResource: K.wordsURL.fileName, withExtension: K.wordsURL.fileExtension) {
            if let wordContents = try? String(contentsOf: fileURL) {
                var lines = wordContents.components(separatedBy: "\n")
                
                lines.shuffle()
                wordStrings += lines
            }
        } else {
            fatalError("No words found!")
        }
        
        delegate?.gameDataFetched(wordStrings)
    }
    
}
