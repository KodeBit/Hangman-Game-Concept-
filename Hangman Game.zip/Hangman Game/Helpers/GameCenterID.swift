//
//  GameCenterID.swift
//  Hangman Game
//
//  Created by Benjamin Clarke on 21/06/2021.
//  Copyright © 2021 Ben Clarke. All rights reserved.
//

import Foundation

struct GameCenterID {
    static let id = "com.vikingskullapps.HangmanWordGame.Scores" //TODO: - Replace with your leaderBoard ID
}
